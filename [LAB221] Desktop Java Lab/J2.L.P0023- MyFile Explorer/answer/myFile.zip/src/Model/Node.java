package Model;

import java.io.File;

public class Node {
    private File parent;

    public Node(File parent) {
        this.parent = parent;
    }

    @Override
    public String toString() {
        return parent.getName()+ "";
    }

    public File getParent() {
        return parent;
    }
}
